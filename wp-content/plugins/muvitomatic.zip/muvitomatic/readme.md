# Muvitomatic for Muvipro

**Installation**
- Upload muvitomatic.zip to Wordpress Plugins
- Insert a License on Muvitomatic License Page
- Save Muvitomatic Setting for the First time.
- done. You can generate the movies

##Movie Generator

### Server
**IMDB**

You can generate the movie from imdb server and filtering by year, genre, etc

**Gdriveplayer**

You can generate Movie, Series or Anime using this server. All movies generate by gdp server is filtered by last updated.


**Support**

https://www.facebook.com/clonesiacom
or
create a ticket from member area.